#!/usr/bin/env python3
"""
BotDojo Trace Enrichment Script v2.0
Updated with contextual tool success determination

Usage:
    python enrich_traces.py input.csv output.csv
"""

import csv
import json
import sys
from datetime import datetime
from typing import Optional, Dict, List, Tuple
import pandas as pd


def extract_tool_name(step: dict) -> Optional[str]:
    """
    Extract and normalise tool name from step
    
    Handles mismatches between display names and internal names
    """
    step_label = step.get('stepLabel', '').strip()
    
    # Known mappings for mismatched names
    TOOL_NAME_MAP = {
        'Update ticket information': 'update_ticket_metadata',
        'Search Documents Tool': 'searchDocuments',
        # Add more as discovered
    }
    
    return TOOL_NAME_MAP.get(step_label, step_label)


def determine_tool_success(tool_name: str, content: any) -> Tuple[bool, bool, str]:
    """
    Determine if tool succeeded/failed based on contextual rules
    
    Returns:
        (succeeded, failed, determination_method) tuple
        - Both succeeded and failed can be False if undetermined
    """
    succeeded = False
    failed = False
    method = "unknown"
    
    # Parse content if it's a string
    if isinstance(content, str):
        try:
            content_obj = json.loads(content)
        except json.JSONDecodeError:
            # Not JSON - treat as raw text
            if content.strip():
                succeeded = True
                method = "inferred_from_text"
            else:
                failed = True
                method = "empty_response"
            return (succeeded, failed, method)
    else:
        content_obj = content
    
    if not content_obj:
        return (False, True, "empty_content")
    
    # Tool-specific contextual handling
    if tool_name == 'searchDocuments':
        method = "contextual_searchDocuments"
        # searchDocuments returns {results: "..."}  without success field
        if 'results' in content_obj:
            results = content_obj['results']
            # Non-empty results = success
            if isinstance(results, str):
                succeeded = bool(results.strip())
                failed = not succeeded
            elif isinstance(results, (list, dict)):
                succeeded = bool(results)
                failed = not succeeded
            else:
                failed = True
        else:
            # No results field = failure
            failed = True
            
    elif tool_name in ['Update ticket information', 'update_ticket_metadata']:
        method = "contextual_update_ticket"
        # update_ticket_metadata has inverted logic + "no updates needed" = success
        success_field = content_obj.get('success')
        message = str(content_obj.get('message', '')).lower()
        
        # Check message for "no updates needed" patterns
        no_update_phrases = [
            'no update',
            'already current',
            'not required',
            'no changes',
            'already set'
        ]
        
        is_no_update_scenario = any(phrase in message for phrase in no_update_phrases)
        
        if is_no_update_scenario:
            # "No updates needed" is SUCCESS, not failure!
            succeeded = True
        elif success_field is True:
            succeeded = True
        elif success_field is False:
            failed = True
        else:
            # No clear indicator
            method = "uncertain_update_ticket"
            
    else:
        # Standard tools: trust the success field if present
        method = "standard_success_field"
        if 'success' in content_obj:
            if content_obj['success'] is True:
                succeeded = True
            elif content_obj['success'] is False:
                failed = True
            else:
                method = "invalid_success_value"
        else:
            # No success field and not a known special tool
            # Assume success if there's substantial content
            method = "inferred_from_content_presence"
            if content_obj and len(str(content_obj)) > 10:
                succeeded = True
    
    return (succeeded, failed, method)


def extract_tool_calls(ai_message_str: str) -> Dict:
    """Extract tool information with contextual success determination"""
    
    result = {
        'tools_called': [],
        'tools_succeeded': [],
        'tools_failed': [],
        'tools_uncertain': [],
        'tool_count': 0,
        'has_escalation': False,
        'has_rag_retrieval': False,
        'has_tracking_lookup': False,
        'total_tool_duration_ms': 0,
        'tool_steps': [],
        'determination_methods': []
    }
    
    if not ai_message_str or pd.isna(ai_message_str):
        return result
    
    try:
        ai_message = json.loads(ai_message_str)
        steps = ai_message.get('steps', [])
        
        for step in steps:
            # Skip non-tool steps
            step_type = step.get('type')
            step_label = step.get('stepLabel', '')
            
            # Skip thinking/output steps
            if step_label in ['Thinking', 'Output', 'thinking', 'output']:
                continue
            
            # Must be a tool step
            if step_type != 'tool' and 'arguments' not in step:
                continue
            
            # Extract clean tool name
            tool_name = extract_tool_name(step)
            if not tool_name:
                continue
                
            result['tools_called'].append(tool_name)
            
            # Determine success/failure with context
            content = step.get('content')
            succeeded, failed, method = determine_tool_success(tool_name, content)
            
            result['determination_methods'].append(f"{tool_name}:{method}")
            
            if succeeded:
                result['tools_succeeded'].append(tool_name)
            elif failed:
                result['tools_failed'].append(tool_name)
            else:
                result['tools_uncertain'].append(tool_name)
            
            # Track specific tool types (normalised names)
            tool_name_lower = tool_name.lower()
            if 'escalate' in tool_name_lower:
                result['has_escalation'] = True
            elif 'search' in tool_name_lower or 'document' in tool_name_lower:
                result['has_rag_retrieval'] = True
            elif 'tracking' in tool_name_lower or 'lookup' in tool_name_lower:
                result['has_tracking_lookup'] = True
            
            # Calculate duration
            start_time = step.get('startTime')
            end_time = step.get('endTime')
            duration_ms = 0
            
            if start_time and end_time:
                try:
                    start = datetime.fromisoformat(start_time.replace('Z', '+00:00'))
                    end = datetime.fromisoformat(end_time.replace('Z', '+00:00'))
                    duration_ms = int((end - start).total_seconds() * 1000)
                    result['total_tool_duration_ms'] += duration_ms
                except Exception as e:
                    pass
            
            # Store detailed step info for debugging
            result['tool_steps'].append({
                'name': tool_name,
                'original_label': step_label,
                'duration_ms': duration_ms,
                'succeeded': succeeded,
                'failed': failed,
                'determination_method': method
            })
        
        result['tool_count'] = len(result['tools_called'])
        
    except json.JSONDecodeError as e:
        print(f"Warning: Could not parse AI Message JSON: {e}", file=sys.stderr)
    except Exception as e:
        print(f"Warning: Error extracting tool data: {e}", file=sys.stderr)
    
    return result


def calculate_tool_metrics(tool_data: Dict) -> Dict:
    """Calculate success rate and reliability score"""
    succeeded_count = len(tool_data['tools_succeeded'])
    failed_count = len(tool_data['tools_failed'])
    uncertain_count = len(tool_data['tools_uncertain'])
    total = succeeded_count + failed_count + uncertain_count
    
    metrics = {
        'tool_success_rate': None,
        'tool_reliability_score': None,
        'tools_with_uncertain_status': uncertain_count
    }
    
    # Success rate: succeeded / (succeeded + failed)
    # Excludes uncertain tools
    determined_total = succeeded_count + failed_count
    if determined_total > 0:
        metrics['tool_success_rate'] = round(succeeded_count / determined_total, 3)
    
    # Reliability score: (succeeded + uncertain) / total
    # More forgiving - assumes uncertain tools probably worked
    if total > 0:
        metrics['tool_reliability_score'] = round((succeeded_count + uncertain_count) / total, 3)
    
    return metrics


def enrich_trace(row: pd.Series) -> pd.Series:
    """Enrich a single trace row with tool data"""
    
    ai_message = row.get('AI Message', '')
    tool_data = extract_tool_calls(ai_message)
    
    # Add tool columns
    row['tools_called'] = ','.join(tool_data['tools_called']) if tool_data['tools_called'] else ''
    row['tool_count'] = tool_data['tool_count']
    row['tools_succeeded'] = ','.join(tool_data['tools_succeeded']) if tool_data['tools_succeeded'] else ''
    row['tools_failed'] = ','.join(tool_data['tools_failed']) if tool_data['tools_failed'] else ''
    row['tools_uncertain'] = ','.join(tool_data['tools_uncertain']) if tool_data['tools_uncertain'] else ''
    
    # Add boolean flags
    row['has_escalation'] = 'TRUE' if tool_data['has_escalation'] else 'FALSE'
    row['has_rag_retrieval'] = 'TRUE' if tool_data['has_rag_retrieval'] else 'FALSE'
    row['has_tracking_lookup'] = 'TRUE' if tool_data['has_tracking_lookup'] else 'FALSE'
    
    # Add duration
    row['total_tool_duration_ms'] = tool_data['total_tool_duration_ms']
    
    # Calculate metrics
    metrics = calculate_tool_metrics(tool_data)
    row['tool_success_rate'] = metrics['tool_success_rate']
    row['tool_reliability_score'] = metrics['tool_reliability_score']
    row['tools_with_uncertain_status'] = metrics['tools_with_uncertain_status']
    
    # Add determination methods for debugging
    row['success_determination_methods'] = ';'.join(tool_data['determination_methods']) if tool_data['determination_methods'] else ''
    
    return row


def group_and_enrich(input_file: str, output_file: str):
    """Main enrichment function"""
    
    print(f"Reading traces from {input_file}...")
    df = pd.read_csv(input_file)
    
    print(f"Processing {len(df)} traces...")
    
    # Group by Flow Session
    if 'Flow Session' not in df.columns:
        print("Error: 'Flow Session' column not found!", file=sys.stderr)
        sys.exit(1)
    
    # Sort by session and time
    df['Start Time'] = pd.to_datetime(df['Start Time'])
    df = df.sort_values(['Flow Session', 'Start Time'])
    
    # Add turn numbers
    df['Turn_Number'] = df.groupby('Flow Session').cumcount() + 1
    df['Total_Turns_in_Session'] = df.groupby('Flow Session')['Flow Session'].transform('count')
    
    # Enrich each row
    print("Enriching traces with tool data...")
    df = df.apply(enrich_trace, axis=1)
    
    # Extract Zendesk conversation ID from Header
    if 'Header' in df.columns:
        def extract_zendesk_id(header_str):
            if pd.isna(header_str):
                return ''
            try:
                header = json.loads(header_str)
                return header.get('botdojo_zendesk_conversation_id', '')
            except:
                return ''
        
        df['zendesk_conversation_id'] = df['Header'].apply(extract_zendesk_id)
    
    # Sort sessions by length (longest first for open coding priority)
    session_lengths = df.groupby('Flow Session').size().sort_values(ascending=False)
    df['_session_length'] = df['Flow Session'].map(session_lengths)
    df = df.sort_values(['_session_length', 'Flow Session', 'Turn_Number'], ascending=[False, True, True])
    df = df.drop('_session_length', axis=1)
    
    # Reorder columns for readability
    priority_cols = [
        'Turn_Number',
        'Total_Turns_in_Session',
        'Flow Session',
        'zendesk_conversation_id',
        'Start Time',
        'End Time',
        'Duration',
        'Status',
        'body.user_message',
        'response.text_output',
        'tools_called',
        'tool_count',
        'tools_succeeded',
        'tools_failed',
        'tools_uncertain',
        'tool_success_rate',
        'tool_reliability_score',
        'has_escalation',
        'has_rag_retrieval',
        'has_tracking_lookup',
        'total_tool_duration_ms',
        'success_determination_methods'
    ]
    
    # Reorder: priority cols first, then rest
    other_cols = [col for col in df.columns if col not in priority_cols]
    final_col_order = [col for col in priority_cols if col in df.columns] + other_cols
    df = df[final_col_order]
    
    # Write output
    print(f"Writing enriched traces to {output_file}...")
    df.to_csv(output_file, index=False)
    
    # Print statistics
    print("\n=== Enrichment Statistics ===")
    print(f"Total traces: {len(df)}")
    print(f"Total sessions: {df['Flow Session'].nunique()}")
    print(f"Traces with tools: {(df['tool_count'] > 0).sum()}")
    print(f"Traces with escalation: {(df['has_escalation'] == 'TRUE').sum()}")
    print(f"Traces with RAG: {(df['has_rag_retrieval'] == 'TRUE').sum()}")
    print(f"Traces with tracking lookup: {(df['has_tracking_lookup'] == 'TRUE').sum()}")
    
    # Tool success statistics
    tools_with_data = df[df['tool_count'] > 0]
    if len(tools_with_data) > 0:
        print("\n=== Tool Success Statistics ===")
        avg_success_rate = tools_with_data['tool_success_rate'].mean()
        avg_reliability = tools_with_data['tool_reliability_score'].mean()
        print(f"Average tool success rate: {avg_success_rate:.1%}" if avg_success_rate else "N/A")
        print(f"Average tool reliability score: {avg_reliability:.1%}" if avg_reliability else "N/A")
        
        # Per-tool statistics
        all_tools_succeeded = ','.join(tools_with_data['tools_succeeded'].dropna()).split(',')
        all_tools_failed = ','.join(tools_with_data['tools_failed'].dropna()).split(',')
        all_tools_called = ','.join(tools_with_data['tools_called'].dropna()).split(',')
        
        unique_tools = set([t for t in all_tools_called if t])
        
        print("\n=== Per-Tool Statistics ===")
        for tool in sorted(unique_tools):
            called = all_tools_called.count(tool)
            succeeded = all_tools_succeeded.count(tool)
            failed = all_tools_failed.count(tool)
            if called > 0:
                success_rate = (succeeded / called) * 100
                print(f"{tool}: {success_rate:.0f}% success ({succeeded}/{called} calls)")
    
    print(f"\nDone! Enriched data saved to {output_file}")


if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("Usage: python enrich_traces.py input.csv output.csv")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    group_and_enrich(input_file, output_file)
