# Research Integration Patterns

Integration patterns for using enriched BotDojo traces in thesis research workflows.

## Chapter 3: Open Coding Analysis

### Finding Failure Patterns

Use enriched metrics to identify genuine failure cases for qualitative analysis:

```python
import pandas as pd

df = pd.read_csv('enriched_traces.csv')

# Filter for meaningful failures (not false negatives)
genuine_failures = df[
    (df['tools_failed'] != '') & 
    (df['tool_success_rate'] < 0.5)
].sort_values('tool_success_rate')

# Export for manual coding
genuine_failures.to_csv('failures_for_coding.csv', index=False)
```

### Stratified Sampling

Sample across different tool performance levels:

```python
# Stratify by success rate
high_success = df[df['tool_success_rate'] > 0.8]
medium_success = df[(df['tool_success_rate'] >= 0.5) & (df['tool_success_rate'] <= 0.8)]
low_success = df[df['tool_success_rate'] < 0.5]

# Sample proportionally or equally
sample = pd.concat([
    high_success.sample(n=10),
    medium_success.sample(n=10),
    low_success.sample(n=10)
])
```

### Temporal Patterns

Identify if tool reliability changes over time:

```python
df['conversation_date'] = pd.to_datetime(df['Created On'])

# Group by week and calculate success rates
weekly_success = df.groupby(df['conversation_date'].dt.to_period('W')).agg({
    'tool_success_rate': 'mean',
    'tool_count': 'sum',
    'has_escalation': 'sum'
})

# Plot trends
weekly_success.plot(y='tool_success_rate', title='Tool Success Rate Over Time')
```

## Chapter 5: Building Evaluators

### Tool-Specific Evaluators

Create evaluators that check specific tool success:

```python
def eval_searchDocuments_worked(trace):
    """Did searchDocuments successfully retrieve relevant context?"""
    if 'searchDocuments' not in trace['tools_called']:
        return None  # Not applicable
    
    if 'searchDocuments' in trace['tools_succeeded']:
        return 1.0  # Success
    elif 'searchDocuments' in trace['tools_failed']:
        return 0.0  # Failure
    else:
        return None  # Uncertain, exclude from metrics

def eval_update_succeeded(trace):
    """Did update_ticket_metadata successfully update ticket?"""
    if 'update_ticket_metadata' not in trace['tools_called']:
        return None
    
    # Remember: "no updates needed" is success
    return 1.0 if 'update_ticket_metadata' in trace['tools_succeeded'] else 0.0
```

### Workflow Evaluators

Check complete workflow success:

```python
def eval_rag_workflow_complete(trace):
    """Did the full RAG workflow complete successfully?"""
    required_tools = ['searchDocuments', 'update_ticket_metadata']
    
    # Check all required tools were called
    called = all(tool in trace['tools_called'] for tool in required_tools)
    if not called:
        return 0.0
    
    # Check all succeeded
    succeeded = all(tool in trace['tools_succeeded'] for tool in required_tools)
    return 1.0 if succeeded else 0.0

def eval_escalation_avoided(trace):
    """Was escalation avoided (handled without human)?"""
    return 0.0 if trace['has_escalation'] else 1.0
```

### Composite Metrics

Combine multiple signals:

```python
def eval_conversation_quality(trace):
    """Overall conversation quality score (0-1)"""
    score = 0.0
    max_score = 0
    
    # Tool reliability (if tools used)
    if trace['tool_count'] > 0 and pd.notna(trace['tool_success_rate']):
        score += trace['tool_success_rate'] * 0.4
        max_score += 0.4
    
    # No escalation bonus
    if not trace['has_escalation']:
        score += 0.3
        max_score += 0.3
    
    # Multi-turn handling (if session data available)
    if trace['turn_count'] <= 3:  # Resolved quickly
        score += 0.3
        max_score += 0.3
    
    return score / max_score if max_score > 0 else None
```

## Chapter 6: Multi-Turn Analysis

### Session-Level Aggregation

Analyse tool performance across entire conversations:

```python
# Group traces by session
sessions = df.groupby('Flow Session').agg({
    'tool_success_rate': ['mean', 'std', 'min', 'max'],
    'tool_count': 'sum',
    'has_escalation': 'any',
    'has_rag_retrieval': 'sum',
    'total_tool_duration_ms': 'sum'
})

# Find sessions with degrading performance
sessions['performance_degraded'] = (
    sessions[('tool_success_rate', 'max')] - 
    sessions[('tool_success_rate', 'min')] > 0.3
)
```

### Turn-by-Turn Analysis

Track how tool usage and success evolves:

```python
# Requires turn_number column in traces
turn_analysis = df.groupby('turn_number').agg({
    'tool_success_rate': 'mean',
    'tool_count': 'mean',
    'has_escalation': lambda x: (x == True).mean()
})

# Plot tool success by turn
turn_analysis.plot(
    y='tool_success_rate',
    title='Tool Success Rate by Conversation Turn',
    xlabel='Turn Number',
    ylabel='Success Rate'
)
```

### Recovery Patterns

Identify if chatbot recovers from failures:

```python
def analyse_recovery_pattern(session_traces):
    """Check if chatbot recovered after initial tool failure"""
    traces = session_traces.sort_values('turn_number')
    
    # Find first failure
    first_failure_idx = traces[traces['tools_failed'] != ''].index.min()
    if pd.isna(first_failure_idx):
        return 'no_failure'
    
    # Check subsequent turns
    later_traces = traces.loc[first_failure_idx + 1:]
    if len(later_traces) == 0:
        return 'failure_final_turn'
    
    # Did any later turn succeed?
    if (later_traces['tool_success_rate'] > 0.8).any():
        return 'recovered'
    elif later_traces['has_escalation'].any():
        return 'escalated'
    else:
        return 'continued_failure'

# Apply to all sessions
recovery_patterns = df.groupby('Flow Session').apply(analyse_recovery_pattern)
```

## Statistical Analysis

### Success Rate Distributions

```python
import matplotlib.pyplot as plt

# Overall distribution
plt.hist(df['tool_success_rate'].dropna(), bins=20)
plt.title('Distribution of Tool Success Rates')
plt.xlabel('Success Rate')
plt.ylabel('Number of Traces')
plt.show()

# Per-tool distributions
for tool in ['searchDocuments', 'update_ticket_metadata', 'tracking_lookup']:
    tool_traces = df[df['tools_called'].str.contains(tool, na=False)]
    print(f"\n{tool} Statistics:")
    print(f"Mean success rate: {tool_traces['tool_success_rate'].mean():.2%}")
    print(f"Median: {tool_traces['tool_success_rate'].median():.2%}")
    print(f"Std dev: {tool_traces['tool_success_rate'].std():.2%}")
```

### Correlation Analysis

```python
# Tool count vs success rate
correlation = df[['tool_count', 'tool_success_rate']].corr()
print(f"Correlation: {correlation.iloc[0, 1]:.3f}")

# Duration vs success
correlation = df[['total_tool_duration_ms', 'tool_success_rate']].corr()
print(f"Duration-Success correlation: {correlation.iloc[0, 1]:.3f}")
```

## Validation Strategies

### Inter-Rater Reliability

Compare automated enrichment with manual coding:

```python
# Sample traces for manual validation
validation_sample = df.sample(n=50, random_state=42)

# After manual coding in validation_sample_coded.csv
manual = pd.read_csv('validation_sample_coded.csv')
automated = validation_sample

# Calculate agreement
from sklearn.metrics import cohen_kappa_score

# Requires binary success/failure for each tool type
kappa = cohen_kappa_score(
    manual['searchDocuments_succeeded'],
    automated['tools_succeeded'].str.contains('searchDocuments', na=False)
)
print(f"Cohen's Kappa: {kappa:.3f}")
```

### Sanity Checks

Verify enrichment isn't producing nonsensical results:

```python
# Check 1: No trace should have success rate > 1.0
assert (df['tool_success_rate'] <= 1.0).all()

# Check 2: If no tools called, success rate should be null
assert df[df['tool_count'] == 0]['tool_success_rate'].isna().all()

# Check 3: tools_succeeded + tools_failed + tools_uncertain should equal tools_called count
def check_tool_counts(row):
    succeeded = len([t for t in row['tools_succeeded'].split(',') if t])
    failed = len([t for t in row['tools_failed'].split(',') if t])
    uncertain = len([t for t in row['tools_uncertain'].split(',') if t])
    called = row['tool_count']
    return succeeded + failed + uncertain == called

assert df[df['tool_count'] > 0].apply(check_tool_counts, axis=1).all()
```

## Export Formats for Analysis Tools

### For MAXQDA/NVivo (Qualitative Coding)

```python
# Export with rich context for manual coding
export_df = df[[
    'Flow Session', 'Created On', 'Conversation', 
    'tools_called', 'tools_succeeded', 'tools_failed',
    'tool_success_rate', 'has_escalation',
    'User Message', 'AI Message'
]].copy()

# Add interpretation columns
export_df['needs_review'] = (
    (export_df['tool_success_rate'] < 0.5) | 
    (export_df['tools_uncertain'] != '')
)

export_df.to_csv('for_qualitative_coding.csv', index=False)
```

### For Tableau/PowerBI (Visualisation)

```python
# Prepare aggregated metrics
viz_df = df.groupby('conversation_date').agg({
    'tool_success_rate': 'mean',
    'tool_count': 'sum',
    'has_escalation': 'sum',
    'has_rag_retrieval': 'sum',
    'Flow Session': 'count'  # Number of traces
}).rename(columns={'Flow Session': 'trace_count'})

viz_df.to_csv('for_visualisation.csv')
```

### For R Statistical Analysis

```python
# Wide format with binary indicators per tool
tools = ['searchDocuments', 'update_ticket_metadata', 'escalateToAgent', 'tracking_lookup']

for tool in tools:
    df[f'{tool}_called'] = df['tools_called'].str.contains(tool, na=False).astype(int)
    df[f'{tool}_succeeded'] = df['tools_succeeded'].str.contains(tool, na=False).astype(int)
    df[f'{tool}_failed'] = df['tools_failed'].str.contains(tool, na=False).astype(int)

# Export wide format
df.to_csv('for_r_analysis.csv', index=False)
```

## Common Pitfalls

### False Positives

**Problem:** Treating "no updates needed" as failure
**Solution:** Contextual interpretation recognises this as success

### Missing Context

**Problem:** Analysing tool success without conversation context
**Solution:** Always review actual conversations when patterns seem odd

### Overfitting to Examples

**Problem:** Detection logic optimised for specific examples
**Solution:** Validate on held-out test set before using for research

### Ignoring Uncertainty

**Problem:** Treating uncertain tools as failed
**Solution:** Use `tool_reliability_score` or investigate uncertain cases

### Temporal Bias

**Problem:** Early conversations may have different characteristics
**Solution:** Control for deployment date in analysis or stratify samples
