# BotDojo Tool Response Formats

This reference documents the observed response formats from BotDojo tools, used for contextual success determination.

## Standard Format

Most tools follow this format:

```json
{
  "success": true,
  "message": "Operation completed",
  "data": { ... }
}
```

Success determination: Trust the `success` field directly.

## Non-Standard Formats

### searchDocuments

**Observed format:**
```json
{
  "results": "Retrieved context about shipping policies..."
}
```

**Issues:**
- No `success` field present
- Empty results still return valid JSON object
- Naive parsing treats all as failures

**Detection logic:**
```python
if 'results' in content_obj:
    results = content_obj['results']
    if isinstance(results, str):
        succeeded = bool(results.strip())  # Non-empty string = success
    elif isinstance(results, (list, dict)):
        succeeded = bool(results)  # Non-empty collection = success
```

**Success indicators:**
- Has `results` field
- Results content is non-empty

**Failure indicators:**
- No `results` field
- Empty results content

### update_ticket_metadata

**Observed formats:**

Success case:
```json
{
  "success": true,
  "message": "Ticket updated with order number #12345"
}
```

"No updates needed" case (falsely marked as failure):
```json
{
  "success": false,
  "message": "No updates required - ticket information is already current"
}
```

**Issues:**
- Returns `success: false` when no changes needed (actually success)
- Message contains success indicators like "no updates required"
- Naive parsing treats "no updates needed" as failure

**Detection logic:**
```python
success_field = content_obj.get('success')
message = str(content_obj.get('message', '')).lower()

no_update_phrases = [
    'no update',
    'already current',
    'not required',
    'no changes',
    'already set'
]

if not success_field and any(phrase in message for phrase in no_update_phrases):
    succeeded = True  # "No updates needed" = success
elif success_field:
    succeeded = True
else:
    failed = True
```

**Success indicators:**
- `success: true`
- OR `success: false` with message containing "no updates", "already current", etc.

**Failure indicators:**
- `success: false` with message indicating actual error (API error, invalid data, etc.)

### escalateToAgent

**Observed format:**
```json
{
  "success": true,
  "message": "Escalated to agent queue"
}
```

**Standard behaviour:** Follows standard format, no special handling needed.

### tracking_lookup

**Observed format:**
```json
{
  "success": true,
  "tracking_info": {
    "status": "delivered",
    "location": "Sydney, AU"
  }
}
```

**Standard behaviour:** Follows standard format, no special handling needed.

## Tool Name Variations

BotDojo uses different names in different contexts:

| Display Name (UI) | Internal Name (API) | Canonical Name (Used in Skill) |
|-------------------|---------------------|--------------------------------|
| Update ticket information | update_ticket_metadata | update_ticket_metadata |
| Search Documents Tool | searchDocuments | searchDocuments |
| Escalate to Agent | escalateToAgent | escalateToAgent |
| Tracking Lookup | tracking_lookup | tracking_lookup |

The enrichment script normalises all variations to canonical names.

## Adding New Tool Formats

When you discover a new tool with non-standard format:

1. Document the observed format here
2. Identify success/failure indicators
3. Add detection logic to `scripts/enrich_traces.py` in `determine_tool_success()`
4. Add name mapping to `extract_tool_name()` if needed
5. Test on sample traces to validate

## Determination Confidence Levels

The script assigns confidence to each determination:

- **High confidence** - Standard `success` field or clear indicators (searchDocuments with results)
- **Medium confidence** - Inferred from message patterns (update_ticket_metadata "no updates")
- **Low confidence** - Guessed from content existence or format
- **Uncertain** - No clear success/failure indicators found

Tools marked as uncertain should be investigated manually to improve detection logic.
