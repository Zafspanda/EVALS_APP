#!/usr/bin/env python3
"""
Compare enrichment results before and after contextual interpretation.

Usage:
    python compare_enrichments.py original.csv enriched.csv
"""

import sys
import pandas as pd
from collections import Counter


def analyse_tool_success_changes(original_df, enriched_df):
    """Compare tool success rates between original and enriched data"""
    
    print("\n" + "=" * 60)
    print("TOOL SUCCESS RATE COMPARISON")
    print("=" * 60)
    
    # Extract all unique tool names
    all_tools = set()
    for df in [original_df, enriched_df]:
        for col in ['tools_called', 'tools_succeeded', 'tools_failed']:
            if col in df.columns:
                tools = df[col].str.split(',').explode().str.strip()
                all_tools.update(tools[tools != ''].unique())
    
    # Calculate success rates per tool
    results = []
    for tool in sorted(all_tools):
        # Original success rate
        orig_called = original_df['tools_called'].str.contains(tool, na=False).sum()
        orig_succeeded = original_df['tools_succeeded'].str.contains(tool, na=False).sum()
        orig_rate = (orig_succeeded / orig_called * 100) if orig_called > 0 else 0
        
        # Enriched success rate
        enr_called = enriched_df['tools_called'].str.contains(tool, na=False).sum()
        enr_succeeded = enriched_df['tools_succeeded'].str.contains(tool, na=False).sum()
        enr_rate = (enr_succeeded / enr_called * 100) if enr_called > 0 else 0
        
        change = enr_rate - orig_rate
        
        results.append({
            'tool': tool,
            'original_rate': orig_rate,
            'enriched_rate': enr_rate,
            'change': change,
            'calls': orig_called
        })
    
    # Sort by absolute change
    results.sort(key=lambda x: abs(x['change']), reverse=True)
    
    print(f"\n{'Tool':<30} {'Original':<12} {'Enriched':<12} {'Change':<12} {'Calls':<8}")
    print("-" * 74)
    
    for r in results:
        change_str = f"+{r['change']:.1f}%" if r['change'] > 0 else f"{r['change']:.1f}%"
        print(f"{r['tool']:<30} {r['original_rate']:>6.1f}% {r['enriched_rate']:>11.1f}% {change_str:>11} {r['calls']:>7}")
    
    return results


def analyse_overall_metrics(original_df, enriched_df):
    """Compare overall metrics"""
    
    print("\n" + "=" * 60)
    print("OVERALL METRICS COMPARISON")
    print("=" * 60)
    
    # Calculate overall success rates
    metrics = []
    
    for name, df in [('Original', original_df), ('Enriched', enriched_df)]:
        total_tools = df['tool_count'].sum()
        
        # Count successes and failures
        succeeded = df['tools_succeeded'].str.split(',').apply(
            lambda x: len([t for t in x if t.strip()]) if isinstance(x, list) else 0
        ).sum()
        
        failed = df['tools_failed'].str.split(',').apply(
            lambda x: len([t for t in x if t.strip()]) if isinstance(x, list) else 0
        ).sum()
        
        success_rate = (succeeded / (succeeded + failed) * 100) if (succeeded + failed) > 0 else 0
        
        # Average per-trace success rate
        avg_trace_success = df['tool_success_rate'].mean() * 100 if 'tool_success_rate' in df.columns else 0
        
        metrics.append({
            'name': name,
            'total_tools': total_tools,
            'succeeded': succeeded,
            'failed': failed,
            'success_rate': success_rate,
            'avg_trace_success': avg_trace_success
        })
    
    print(f"\n{'Metric':<30} {'Original':<15} {'Enriched':<15} {'Change':<12}")
    print("-" * 72)
    
    for i, metric in enumerate(['total_tools', 'succeeded', 'failed', 'success_rate', 'avg_trace_success']):
        orig_val = metrics[0][metric]
        enr_val = metrics[1][metric]
        
        if metric in ['success_rate', 'avg_trace_success']:
            change = enr_val - orig_val
            print(f"{metric:<30} {orig_val:>10.1f}% {enr_val:>14.1f}% {change:>+10.1f}%")
        else:
            change = enr_val - orig_val
            print(f"{metric:<30} {orig_val:>14.0f} {enr_val:>14.0f} {change:>+11.0f}")


def analyse_uncertainty(enriched_df):
    """Analyse tools marked as uncertain"""
    
    if 'tools_uncertain' not in enriched_df.columns:
        return
    
    print("\n" + "=" * 60)
    print("UNCERTAINTY ANALYSIS")
    print("=" * 60)
    
    uncertain_tools = enriched_df['tools_uncertain'].str.split(',').explode().str.strip()
    uncertain_tools = uncertain_tools[uncertain_tools != '']
    
    if len(uncertain_tools) == 0:
        print("\nNo uncertain tool calls found. All tools have clear success/failure indicators.")
        return
    
    uncertainty_counts = Counter(uncertain_tools)
    
    print(f"\nTotal uncertain tool calls: {len(uncertain_tools)}")
    print(f"\n{'Tool':<30} {'Uncertain Calls':<20}")
    print("-" * 50)
    
    for tool, count in uncertainty_counts.most_common():
        print(f"{tool:<30} {count:<20}")
    
    print("\nRecommendation: Add detection logic for these tools in determine_tool_success()")


def analyse_determination_methods(enriched_df):
    """Analyse how success was determined"""
    
    if 'success_determination_methods' not in enriched_df.columns:
        return
    
    print("\n" + "=" * 60)
    print("DETERMINATION METHODS")
    print("=" * 60)
    
    # Parse determination methods
    all_methods = []
    for methods_str in enriched_df['success_determination_methods'].dropna():
        if methods_str and methods_str.strip():
            # Format: "tool1:method1;tool2:method2"
            for pair in methods_str.split(';'):
                if ':' in pair:
                    tool, method = pair.split(':', 1)
                    all_methods.append((tool.strip(), method.strip()))
    
    if not all_methods:
        return
    
    # Count by method type
    method_counts = Counter(method for _, method in all_methods)
    
    print(f"\n{'Method':<30} {'Count':<10} {'Percentage':<12}")
    print("-" * 52)
    
    total = sum(method_counts.values())
    for method, count in method_counts.most_common():
        pct = (count / total * 100) if total > 0 else 0
        print(f"{method:<30} {count:<10} {pct:>6.1f}%")
    
    # Count by tool
    tool_methods = {}
    for tool, method in all_methods:
        if tool not in tool_methods:
            tool_methods[tool] = []
        tool_methods[tool].append(method)
    
    print(f"\n{'Tool':<30} {'Primary Method':<30}")
    print("-" * 60)
    
    for tool, methods in sorted(tool_methods.items()):
        primary = Counter(methods).most_common(1)[0][0]
        print(f"{tool:<30} {primary:<30}")


def main():
    if len(sys.argv) != 3:
        print("Usage: python compare_enrichments.py original.csv enriched.csv")
        sys.exit(1)
    
    original_path = sys.argv[1]
    enriched_path = sys.argv[2]
    
    try:
        original_df = pd.read_csv(original_path)
        enriched_df = pd.read_csv(enriched_path)
    except Exception as e:
        print(f"Error loading files: {e}")
        sys.exit(1)
    
    # Verify both have required columns
    required_cols = ['tools_called', 'tools_succeeded', 'tools_failed', 'tool_count']
    for col in required_cols:
        if col not in original_df.columns:
            print(f"Error: Original file missing column '{col}'")
            sys.exit(1)
        if col not in enriched_df.columns:
            print(f"Error: Enriched file missing column '{col}'")
            sys.exit(1)
    
    print("\nBotDojo Enrichment Comparison Report")
    print(f"Original: {original_path} ({len(original_df)} traces)")
    print(f"Enriched: {enriched_path} ({len(enriched_df)} traces)")
    
    # Run analyses
    analyse_overall_metrics(original_df, enriched_df)
    analyse_tool_success_changes(original_df, enriched_df)
    analyse_uncertainty(enriched_df)
    analyse_determination_methods(enriched_df)
    
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print("\nKey Findings:")
    print("1. Check which tools had the largest success rate changes")
    print("2. Verify the changes align with expectations (e.g., searchDocuments improving)")
    print("3. Investigate any uncertain tools that need detection logic")
    print("4. Ensure contextual methods are being used where needed")
    
    print("\n" + "=" * 60 + "\n")


if __name__ == '__main__':
    main()
