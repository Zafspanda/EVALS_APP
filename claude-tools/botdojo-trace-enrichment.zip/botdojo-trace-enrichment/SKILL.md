---
name: botdojo-trace-enrichment
description: Enrich BotDojo conversation traces with accurate tool success metrics using contextual interpretation. Use when analysing BotDojo chatbot performance, debugging tool failures, conducting open coding on conversation traces, or building evaluators for LLM-powered customer support flows. Handles non-standard tool response formats (searchDocuments missing success field, update_ticket_metadata inverted logic) to provide realistic success rates instead of false negatives.
license: Complete terms in LICENSE.txt
---

# BotDojo Trace Enrichment

Enrich exported BotDojo conversation traces with accurate tool metrics through contextual interpretation of tool results. Solves systematic under-reporting of tool success rates caused by non-standard response formats.

## When to Use This Skill

Use this skill when:
- Analysing BotDojo chatbot performance and tool reliability
- Conducting open coding analysis on conversation traces (Chapter 3 research)
- Building automated evaluators for LLM agent workflows (Chapter 5)
- Debugging why tools appear broken when they're actually working
- Comparing tool performance across different conversation scenarios

## Quick Start

```bash
# Enrich BotDojo CSV export with accurate metrics
python scripts/enrich_traces.py input.csv output.csv
```

The script adds these columns:
- `tools_succeeded`, `tools_failed`, `tools_uncertain` - Contextually determined success
- `tool_success_rate` - Percentage of determined successes
- `tool_reliability_score` - Success rate including uncertain as positive
- `success_determination_methods` - How each tool's success was evaluated

## Core Problem

BotDojo tools return results in inconsistent formats:

1. **searchDocuments** - Returns `{results: "..."}` without `success` field
2. **update_ticket_metadata** - Returns `success: false` when "no updates needed" (actually success)
3. **Standard tools** - Return `{success: true/false, ...}` as expected

Naive parsing treats missing `success` fields and inverted logic as failures, causing:
- searchDocuments: 0% success (actually 100%)
- update_ticket_metadata: 0% success (actually 70-90%)
- Overall tool health: 50% broken (actually 90%+ working)

## Solution: Contextual Interpretation

The enrichment script uses tool-specific logic:

**searchDocuments**: Check if `results` field exists and is non-empty → success
**update_ticket_metadata**: Check message for "no updates needed" patterns → success
**Standard tools**: Trust the `success` field → success if true

This produces realistic metrics that match actual chatbot performance.

## Script Usage

### Basic Enrichment

```bash
python scripts/enrich_traces.py Demo_Traces.csv Demo_Enriched.csv
```

### Validation

The script outputs per-tool statistics:

```
=== Tool Success Statistics ===
Average tool success rate: 85.2%
Average tool reliability score: 91.3%

=== Per-Tool Statistics ===
searchDocuments: 100% success (9/9 calls)
update_ticket_metadata: 78% success (7/9 calls)
escalateToAgent: 100% success (9/9 calls)
tracking_lookup: 80% success (8/10 calls)
```

Compare these to your intuition of tool reliability. If searchDocuments was showing 0% before and 100% after, the enrichment is working correctly.

## Output Columns

### New Columns Added

- **tools_uncertain** - Tools where success couldn't be determined (empty string or tool names)
- **tool_success_rate** - Float 0-1: succeeded / (succeeded + failed), excludes uncertain
- **tool_reliability_score** - Float 0-1: (succeeded + uncertain) / total, more forgiving
- **success_determination_methods** - String showing evaluation method per tool (e.g., "searchDocuments:contextual;escalateToAgent:standard")

### Modified Columns

- **tools_succeeded** - Now uses contextual interpretation, dramatically different from naive parsing
- **tools_failed** - Now excludes false negatives from non-standard formats

## Integration Examples

### Finding Genuine Tool Failures

```python
import pandas as pd

df = pd.read_csv('enriched_traces.csv')

# Find traces where tools actually failed (not false negatives)
genuine_failures = df[
    (df['tools_failed'] != '') &
    (df['tool_success_rate'] < 0.5)  # More than half failed
].sort_values('tool_success_rate')

# These are real failures worth investigating
```

### Building Evaluators

```python
def eval_searchDocuments_worked(trace):
    """Did searchDocuments successfully retrieve context?"""
    if 'searchDocuments' in trace['tools_called']:
        return 'searchDocuments' in trace['tools_succeeded']
    return None  # Not applicable

# Now correctly identifies when retrieval worked
# Before: Flagged 100% as failures (false negatives)
# After: Accurate success detection
```

### Multi-Turn Analysis

```python
# Track tool reliability across conversation
sessions = df.groupby('Flow Session')

for session_id, traces in sessions:
    success_rates = traces['tool_success_rate'].dropna()
    
    if len(success_rates) > 0:
        # Is reliability degrading during conversation?
        if success_rates.iloc[-1] < success_rates.iloc[0] - 0.3:
            print(f"Session {session_id}: Tool reliability degraded")
```

## Extending for Custom Tools

If you have custom tools with non-standard formats, add detection logic to `scripts/enrich_traces.py`:

```python
# In determine_tool_success() function
elif tool_name == 'your_custom_tool':
    method = "contextual_your_tool"
    # Your custom logic here
    if 'specific_field' in content_obj:
        succeeded = True
    else:
        failed = True
```

Then add the tool name mapping if display names differ:

```python
# In extract_tool_name() function
TOOL_NAME_MAP = {
    'Display Name': 'internal_name',
    # ... existing mappings
}
```

## Troubleshooting

### Unexpected Success Rates

Check `success_determination_methods` column to see how each tool was evaluated:
- `contextual` - Used tool-specific logic
- `standard` - Used success field
- `inferred` - Guessed from content
- `empty_response` - Marked as failed

### High Uncertain Count

Tools in `tools_uncertain` need investigation:
1. Look at raw tool responses in BotDojo
2. Add detection logic to `determine_tool_success()`
3. Or accept using `tool_reliability_score` instead

### Tool Name Mismatches

If tools aren't being recognised, check `tools_called` column and add mapping to `TOOL_NAME_MAP` in `extract_tool_name()` function.

## Expected Impact

### Before Enrichment
```
Overall tool health: 50% (2/4 tools working)
- searchDocuments: 0% ❌ FALSE NEGATIVE
- update_ticket_metadata: 0% ❌ FALSE NEGATIVE  
- escalateToAgent: 100% ✅
- tracking_lookup: 80% ✅
```

### After Enrichment
```
Overall tool health: 90% (4/4 tools working)
- searchDocuments: 100% ✅ CORRECTED
- update_ticket_metadata: 78% ✅ CORRECTED
- escalateToAgent: 100% ✅
- tracking_lookup: 80% ✅
```

## Advanced Usage

### Re-enriching Historical Data

To update old analyses with corrected metrics:

```bash
# Re-run on historical exports
python scripts/enrich_traces.py old_traces.csv old_traces_corrected.csv

# Compare before/after
python scripts/compare_enrichments.py old_traces.csv old_traces_corrected.csv
```

### Custom Validation Rules

For research requiring specific validation profiles, modify the script's determination logic or create a separate validator:

```python
def strict_validation(trace):
    """Only count explicit success=true as success"""
    # Custom logic here
    pass
```

## Files in This Skill

- `scripts/enrich_traces.py` - Main enrichment script with contextual interpretation
- `scripts/compare_enrichments.py` - Compare before/after enrichment statistics
- `references/tool-formats.md` - Documentation of known tool response formats
- `references/research-integration.md` - Integration patterns for thesis research workflows

## Common Questions

**Q: Will this change my historical analysis?**
A: Yes, if you re-run on old traces. New success rates will be higher and more accurate.

**Q: Should I fix the tools in BotDojo?**
A: Ideally yes, but the enrichment workaround is fine for analysis. To fix at source:
1. Add `success: true` to searchDocuments subflow output
2. Fix update_ticket_metadata logic (return success for "no updates needed")

**Q: What about tools not listed here?**
A: Script falls back to standard `success` field parsing for unknown tools. Add custom logic if needed.

**Q: How do I handle uncertain tools?**
A: Three strategies:
1. Investigate - Add logging to see why determination failed
2. Assume success - Use `tool_reliability_score` metric
3. Ignore - Filter traces with `tools_uncertain != ""`
